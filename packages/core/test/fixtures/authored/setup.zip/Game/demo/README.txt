Authored fixture project for the package-loader tests (ticket 2.22).
